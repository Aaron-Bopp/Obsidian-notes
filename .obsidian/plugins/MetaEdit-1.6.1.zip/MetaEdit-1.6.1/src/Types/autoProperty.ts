export interface AutoProperty {
    name: string,
    choices: string[]
}