export interface KanbanProperty {
    boardName: string,
    property: string
}