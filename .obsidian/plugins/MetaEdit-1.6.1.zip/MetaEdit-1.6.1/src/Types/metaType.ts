export enum MetaType {
    YAML, Dataview, Tag, Option
}