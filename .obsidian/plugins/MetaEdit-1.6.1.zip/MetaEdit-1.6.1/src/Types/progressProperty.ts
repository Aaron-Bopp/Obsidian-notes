import type {ProgressPropertyOptions} from "./progressPropertyOptions";

export interface ProgressProperty {
    name: string;
    type: ProgressPropertyOptions
}