export enum ProgressPropertyOptions {
    TaskTotal = "Total Tasks",
    TaskComplete = "Completed Tasks",
    TaskIncomplete = "Incomplete Tasks"
}