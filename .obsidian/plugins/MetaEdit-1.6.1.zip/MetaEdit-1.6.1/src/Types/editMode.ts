export enum EditMode {
    AllSingle = "All Single",
    AllMulti = "All Multi",
    SomeMulti = "Some Multi",
}